function selectBestCountry() {
  return "Argentina";
}
